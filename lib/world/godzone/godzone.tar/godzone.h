inherit ROOM;

#define ROOM_PATH "/world/godzone/"

